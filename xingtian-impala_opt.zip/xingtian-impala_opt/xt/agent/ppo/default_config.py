"""default config for ppo agent."""
GAMMA = 0.99
LAM = 0.95
