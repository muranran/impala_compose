from zeus.common.util.register import register_xt_defaults, Registers
