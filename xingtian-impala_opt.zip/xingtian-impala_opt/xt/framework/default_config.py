LIB = False
ACTOR_FILE = "act_launcher.py"
DEFAULT_NODE_CONFIG = [["127.0.0.1", "username", "passwd"]]
