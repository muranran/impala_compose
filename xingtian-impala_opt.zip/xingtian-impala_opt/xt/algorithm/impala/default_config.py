"""Set static variables in impala."""

GAMMA = 0.99
BATCH_SIZE = 512
