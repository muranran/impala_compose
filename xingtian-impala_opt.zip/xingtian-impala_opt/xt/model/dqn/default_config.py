"""Create deault config for DDPG."""

HIDDEN_SIZE = 128
NUM_LAYERS = 1
LR = 0.0003
