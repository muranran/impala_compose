from .adapter import TfAdapter
from .imagenet import Imagenet
