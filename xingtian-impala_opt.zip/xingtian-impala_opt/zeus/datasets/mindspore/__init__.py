from .adapter import MsAdapter
